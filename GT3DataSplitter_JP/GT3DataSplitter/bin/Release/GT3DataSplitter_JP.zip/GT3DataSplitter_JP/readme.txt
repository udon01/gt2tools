=================================================================
GT3DataSplitter by pez2k
=================================================================

Note: This is a modified and released version of pez2k's code by udon_01y.
The original code
https://github.com/pez2k/gt2tools/tree/master/GT3DataSplitter

I have done this with permission, but pez2k cannot support it because it is different from the original code.

=================================================================
treatment

1. place the files in the database in the same location as GT3DataSplitter.exe
2. drag and drop any of the files
3. the files will be extracted

Double-click the exe when you want to undo it.

Note: that RearDownforceMax and RearDownforceDefault in RacingModify are swapped.
=================================================================

=================================================================
Credits:

Original code: pez2k
Modify: udon_01y
=================================================================